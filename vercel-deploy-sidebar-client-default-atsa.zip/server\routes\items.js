import express from "express";
import mongoose from "mongoose";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { Client } from "../models/Client.js";
import { Item } from "../models/Item.js";
import { AppSetting } from "../models/AppSetting.js";
import { filesToAttachments, upload } from "../config/upload.js";

export const itemsRouter = express.Router();
const BASE_CATEGORIES = ["Memos", "Códigos", "Prestadores", "Auditoría", "Inclusiones"];

itemsRouter.use(requireAuth);

itemsRouter.get("/", async (req, res) => {
  const query = await buildItemQuery(req.query, req.user);
  const sort = itemSort(req.query.sort, req.query.direction);
  const page = Math.max(Number(req.query.page) || 1, 1);
  const limit = Math.min(Math.max(Number(req.query.limit) || 20, 1), 50);

  if (req.query.sort === "client") {
    const [items, total] = await Promise.all([
      Item.aggregate([
        { $match: query },
        { $lookup: { from: "clients", localField: "client", foreignField: "_id", as: "clientDoc" } },
        { $unwind: { path: "$clientDoc", preserveNullAndEmptyArrays: true } },
        { $sort: sort },
        { $skip: (page - 1) * limit },
        { $limit: limit },
        { $lookup: { from: "users", localField: "createdBy", foreignField: "_id", as: "createdBy" } },
        { $unwind: { path: "$createdBy", preserveNullAndEmptyArrays: true } },
        { $project: { clientDoc: 0, "createdBy.passwordHash": 0 } },
      ]).collation({ locale: "es", strength: 1 }),
      Item.countDocuments(query),
    ]);

    return res.json({
      items: items.map(serializeItem),
      page,
      total,
      hasMore: page * limit < total,
    });
  }

  const [items, total] = await Promise.all([
    Item.find(query)
      .populate("createdBy", "name email avatar role")
      .sort(sort)
      .collation({ locale: "es", strength: 1 })
      .skip((page - 1) * limit)
      .limit(limit),
    Item.countDocuments(query),
  ]);

  res.json({
    items: items.map(serializeItem),
    page,
    total,
    hasMore: page * limit < total,
  });
});

itemsRouter.get("/categories", async (_req, res) => {
  res.json({ categories: await loadCategories() });
});

itemsRouter.post("/categories", requireRole("admin"), async (req, res) => {
  const category = normalizeCategory(req.body.category);
  if (!category) return res.status(400).json({ message: "La categoria es obligatoria." });

  const categories = mergeCategories([...(await loadCategories()), category]);
  await AppSetting.findOneAndUpdate(
    { key: "itemCategories" },
    { $set: { value: { categories } } },
    { upsert: true, new: true }
  );
  res.status(201).json({ categories });
});

itemsRouter.post("/", requireRole("admin", "collaborator"), upload.array("attachments"), async (req, res) => {
  const clientIds = itemClientIds(req.body);
  if (!clientIds.length) return res.status(400).json({ message: "Selecciona al menos un cliente." });
  if (!(await isAllowedCategory(req.body.category))) {
    return res.status(400).json({ message: "Selecciona una categoria valida." });
  }

  const attachments = await filesToAttachments(req.files);
  const items = await Item.create(
    clientIds.map((client) => ({
      client,
      subject: req.body.subject,
      date: req.body.date,
      importance: req.body.importance,
      importanceRank: toImportanceRank(req.body.importance),
      category: req.body.category,
      subcategory: providerSubcategory(req.body.category, req.body.subcategory),
      description: req.body.description,
      attachments,
      favorite: false,
      createdBy: req.user._id,
    }))
  );

  const populatedItems = await Item.find({ _id: { $in: items.map((item) => item._id) } }).populate("createdBy", "name email avatar role");
  res.status(201).json({
    item: serializeItem(populatedItems[0]),
    items: populatedItems.map(serializeItem),
    count: populatedItems.length,
  });
});

itemsRouter.patch("/:id", requireRole("admin", "collaborator"), upload.array("attachments"), async (req, res) => {
  const clientIds = itemClientIds(req.body);
  if (!clientIds.length) return res.status(400).json({ message: "Selecciona al menos un cliente." });

  const primaryClient = req.body.client || clientIds[0];
  const sourceItem = await Item.findById(req.params.id);
  if (!sourceItem) return res.status(404).json({ message: "Registro no encontrado." });
  if (!(await isAllowedCategory(req.body.category))) {
    return res.status(400).json({ message: "Selecciona una categoria valida." });
  }

  const update = {
    $set: {
      client: primaryClient,
      subject: req.body.subject,
      date: req.body.date,
      importance: req.body.importance,
      importanceRank: toImportanceRank(req.body.importance),
      category: req.body.category,
      subcategory: providerSubcategory(req.body.category, req.body.subcategory),
      description: req.body.description,
    },
  };

  const newAttachments = await filesToAttachments(req.files);
  if (newAttachments.length) {
    update.$push = { attachments: { $each: newAttachments } };
  }

  const item = await Item.findByIdAndUpdate(req.params.id, update, {
    new: true,
    runValidators: true,
  }).populate("createdBy", "name email avatar role");

  const extraClients = clientIds.filter((client) => String(client) !== String(primaryClient));
  const existingCopies = extraClients.length
    ? await Item.find({
        _id: { $ne: req.params.id },
        client: { $in: extraClients },
        subject: req.body.subject,
        category: req.body.category,
        date: new Date(req.body.date),
      }).select("client")
    : [];
  const existingClientIds = new Set(existingCopies.map((entry) => String(entry.client)));
  const clientsToCreate = extraClients.filter((client) => !existingClientIds.has(String(client)));
  const createdItems = clientsToCreate.length
    ? await Item.create(
        clientsToCreate.map((client) => ({
          client,
          subject: req.body.subject,
          date: req.body.date,
          importance: req.body.importance,
          importanceRank: toImportanceRank(req.body.importance),
          category: req.body.category,
          subcategory: providerSubcategory(req.body.category, req.body.subcategory),
          description: req.body.description,
          attachments: item.attachments.map(plainAttachment),
          favorite: false,
          createdBy: req.user._id,
        }))
      )
    : [];

  const populatedCreatedItems = createdItems.length
    ? await Item.find({ _id: { $in: createdItems.map((entry) => entry._id) } }).populate("createdBy", "name email avatar role")
    : [];

  res.json({
    item: serializeItem(item),
    items: [item, ...populatedCreatedItems].map(serializeItem),
    count: 1 + populatedCreatedItems.length,
  });
});

itemsRouter.patch("/:id/favorite", requireRole("admin"), async (req, res) => {
  const item = await Item.findByIdAndUpdate(
    req.params.id,
    { $set: { favorite: Boolean(req.body.favorite) } },
    { new: true, runValidators: true }
  ).populate("createdBy", "name email avatar role");

  if (!item) return res.status(404).json({ message: "Registro no encontrado." });
  res.json({ item: serializeItem(item) });
});

itemsRouter.delete("/:id", requireRole("admin"), async (req, res) => {
  const item = await Item.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ message: "Registro no encontrado." });
  res.json({ ok: true });
});

async function buildItemQuery(params, user) {
  const query = {};

  if (params.client) query.client = params.client;
  if (params.creator && user?.role === "admin") {
    const creatorIds = toList(params.creator)
      .filter((id) => mongoose.Types.ObjectId.isValid(id))
      .map((id) => new mongoose.Types.ObjectId(id));
    if (creatorIds.length) query.createdBy = { $in: creatorIds };
  }
  if (params.importance) query.importance = { $in: toList(params.importance) };
  if (params.category) query.category = { $in: toList(params.category).map((value) => exactRegex(value)) };
  if (params.keyword) {
    const keyword = String(params.keyword).trim();
    const keywordRegex = new RegExp(escapeRegExp(keyword), "i");
    const matchingClients = await Client.find({ name: keywordRegex }).select("_id");
    query.$or = [
      { subject: keywordRegex },
      { category: keywordRegex },
      { subcategory: keywordRegex },
      { description: keywordRegex },
      { client: { $in: matchingClients.map((client) => client._id) } },
    ];
  }
  if (params.from || params.to) {
    query.date = {};
    if (params.from) query.date.$gte = new Date(params.from);
    if (params.to) query.date.$lte = new Date(params.to);
  }

  return query;
}

function serializeItem(item) {
  return {
    id: item.id || String(item._id),
    client: item.client,
    subject: item.subject,
    date: item.date,
    importance: item.importance,
    category: item.category,
    subcategory: item.subcategory || "",
    description: item.description,
    attachments: item.attachments,
    favorite: Boolean(item.favorite),
    createdBy: item.createdBy,
    createdAt: item.createdAt,
    updatedAt: item.updatedAt,
  };
}

function itemSort(sort, direction) {
  const dir = direction === "asc" ? 1 : -1;
  if (sort === "importance") return { importanceRank: dir, subject: 1, date: -1, createdAt: -1 };
  if (sort === "date") return { date: dir, subject: 1, createdAt: -1 };
  if (sort === "client") return { "clientDoc.name": dir, subject: 1, date: -1, createdAt: -1 };
  return { favorite: -1, subject: dir, date: -1, createdAt: -1 };
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function toImportanceRank(value) {
  return { alta: 1, media: 2, baja: 3 }[value] || 2;
}

function toList(value) {
  return String(value)
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

async function loadCategories() {
  const [setting, itemCategories] = await Promise.all([
    AppSetting.findOne({ key: "itemCategories" }).lean(),
    Item.distinct("category"),
  ]);
  return mergeCategories([
    ...BASE_CATEGORIES,
    ...((setting?.value?.categories || [])),
    ...itemCategories,
  ]);
}

function mergeCategories(categories) {
  const normalized = new Map();
  categories.forEach((category) => {
    const clean = normalizeCategory(category);
    if (!clean) return;
    normalized.set(categoryKey(clean), clean);
  });
  return [...normalized.values()].sort((a, b) => a.localeCompare(b, "es", { sensitivity: "base" }));
}

function normalizeCategory(category) {
  return String(category || "").trim();
}

async function isAllowedCategory(category) {
  const normalized = categoryKey(normalizeCategory(category));
  if (!normalized) return false;
  const categories = await loadCategories();
  return categories.some((entry) => categoryKey(entry) === normalized);
}

function categoryKey(category) {
  return String(category || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("es");
}

function isProviderCategory(category) {
  return categoryKey(category) === "prestadores";
}

function providerSubcategory(category, subcategory) {
  return isProviderCategory(category) ? String(subcategory || "").trim() : "";
}

function itemClientIds(body) {
  const rawClients = body.clients || body.client;
  let clients = [];

  if (rawClients == null) {
    clients = [];
  } else if (Array.isArray(rawClients)) {
    clients = rawClients;
  } else if (typeof rawClients === "string" && rawClients.trim().startsWith("[")) {
    try {
      clients = JSON.parse(rawClients);
    } catch {
      clients = [body.client];
    }
  } else {
    clients = toList(rawClients);
  }

  return [...new Set(clients.map((client) => String(client).trim()).filter(Boolean))];
}

function plainAttachment(attachment) {
  return {
    originalName: attachment.originalName,
    storedName: attachment.storedName,
    mimeType: attachment.mimeType,
    size: attachment.size,
    url: attachment.url,
  };
}

function exactRegex(value) {
  return new RegExp(`^${escapeRegExp(value)}$`, "i");
}
